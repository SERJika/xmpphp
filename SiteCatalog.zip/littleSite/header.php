<html>
<header>
<meta charset="utf-8">
<link rel="stylesheet" href="css/style.css">
<title>Сайт</title>
</header>
<body>
<nav>
    <ul>
        <li class="inline"><a href="?page=main">Главная</a></li>
        <li class="inline"><a href="?page=about">О нас</a></li>
        <li class="inline"><a href="?page=catalog">Каталог</a></li>
        <li class="inline"><a href="?page=contacts">Контакты</a></li>
    </ul>
</nav>
<p>----------------------------------</p>

