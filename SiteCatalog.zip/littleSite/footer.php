<footer>
<p>----------------------------------</p>
<p> Copyright </p>
</footer>
</body>
</html>